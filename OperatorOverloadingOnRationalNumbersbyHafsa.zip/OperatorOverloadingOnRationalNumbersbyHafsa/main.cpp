#include <iostream>
#include "Rational.h"
using namespace std;

int main() {
    Rational frac1, frac2;
    int choice = -1;

    cout << "Enter values for Fraction 1:" << endl;
    cin >> frac1;

    cout << "Enter values for Fraction 2:" << endl;
    cin >> frac2;
    while (choice != 0) {
        cout << endl;
        cout << endl;
        cout << "Rational Number Calculator Menu:" << endl;
        cout << "1. Enter values for Fraction 1" << endl;
        cout << "2. Enter values for Fraction 2" << endl;
        cout << "3. Perform Addition" << endl;
        cout << "4. Perform Subtraction" << endl;
        cout << "5. Perform Multiplication" << endl;
        cout << "6. Perform Division" << endl;
        cout << "7. Check Equality" << endl;
        cout << "8. Check Less Than or Equal" << endl;
        cout << "9. Check Greater Than or Equal" << endl;
        cout << "0. Exit" << endl;
        cout << "Enter your choice: ";

        cin >> choice;

        switch (choice) {
        case 1:
            cout << "Enter values for Fraction 1:" << endl;
            cin >> frac1;
            break;

        case 2:
            cout << "Enter values for Fraction 2:" << endl;
            cin >> frac2;
            break;

        case 3:
            cout << "Result obtained after Addition is " << (frac1 + frac2) << endl;
            break;

        case 4:
            cout << "Result obtained after Subtraction is " << (frac1 - frac2) << endl;
            break;

        case 5:
            cout << "Result obtained after Multiplication is " << (frac1 * frac2) << endl;
            break;

        case 6:
            cout << "Result obtained after Division is " << (frac1 / frac2) << endl;
            break;

        case 7:
            if (frac1 == frac2)
                cout << "Frac1 and Frac2 are Equal" << endl;
            else
                cout << "Frac1 and Frac2 are Not Equal" << endl;
            break;

        case 8:
            if (frac1 <= frac2)
                cout << "Fraction 1 is less than or Equal to Fraction 2 " << endl;
            else
                cout << " Fraction 1 is Greater than Fraction 2 " << endl;
            break;

        case 9:
            if (frac1 >= frac2)
                cout << "Fraction 1 is Greater than or Equal to Fraction 2 " << endl;
            else
                cout << "Fraction 2 is Less than Fraction 1 " << endl;
            break;

        case 0:
            cout << "Exiting the program." << endl;
            break;

        default:
            cout << "Invalid choice. Please try again." << endl;
        }
    }
    cout << "###############################################" << endl;
    cout << "##          NAME:                             #" << endl;
    cout << "##               HAFSA SHAKEEL                #" << endl;
    cout << "##                                            #" << endl;
    cout << "##          ROLL NO :                         #" << endl;
    cout << "##                  22I - 1966                #" << endl;
    cout << "###############################################" << endl;
    return 0;
}

