
#define RATIONAL_H
#include<iostream>
using namespace std;
class Rational {
private:
    int nume, denume;

public:
    Rational();
    Rational(int nume, int denume);

    static int gcd(int a, int b);
    static void simplify(int& numerator, int& denominator);

    Rational operator+(const Rational& other) const;
    Rational operator-(const Rational& other) const;
    Rational operator*(const Rational& other) const;
    Rational operator/(const Rational& other) const;
    bool operator==(const Rational& other) const;
    bool operator!=(const Rational& other) const;
    bool operator<=(const Rational& other) const;
    bool operator>=(const Rational& other) const;
    Rational& operator++();
    Rational operator++(int);
    Rational& operator--();
    Rational operator--(int);
    Rational& operator=(const Rational& other);
    Rational& operator+=(const Rational& other);
    Rational& operator-=(const Rational& other);
    Rational& operator*=(const Rational& other);
    Rational& operator/=(const Rational& other);

    friend istream& operator>>(istream& in, Rational& rational);
    friend ostream& operator<<(ostream& out, const Rational& rational);
};
