#include "Rational.h"
#include<iostream>
using namespace std;

Rational::Rational() : nume(0), denume(1) { }

Rational::Rational(int nume, int denume) : nume(nume), denume(denume) { }

int Rational::gcd(int a, int b) {
    if (b == 0)
        return a;
    return gcd(b, a % b);
}

void Rational::simplify(int& numerator, int& denominator) {
    if (numerator < 0) {
        numerator = -numerator;
        denominator = -denominator;
    }
    int common = gcd(numerator, denominator);
    numerator /= common;
    denominator /= common;
}

Rational Rational::operator+(const Rational& other) const {
    int resultantNumerator = (nume * other.denume) + (other.nume * denume);
    int resultantDenominator = denume * other.denume;
    simplify(resultantNumerator, resultantDenominator);
    return Rational(resultantNumerator, resultantDenominator);
}

Rational Rational::operator-(const Rational& other) const {
    int resultantNumerator = (nume * other.denume) - (other.nume * denume);
    int resultantDenominator = denume * other.denume;
    simplify(resultantNumerator, resultantDenominator);
    return Rational(resultantNumerator, resultantDenominator);
}

Rational Rational::operator*(const Rational& other) const {
    int resultantNumerator = nume * other.nume;
    int resultantDenominator = denume * other.denume;
    simplify(resultantNumerator, resultantDenominator);
    return Rational(resultantNumerator, resultantDenominator);
}

Rational Rational::operator/(const Rational& other) const {
    int resultantNumerator = nume * other.denume;
    int resultantDenominator = denume * other.nume;
    simplify(resultantNumerator, resultantDenominator);
    return Rational(resultantNumerator, resultantDenominator);
}

bool Rational::operator==(const Rational& other) const {
    return (nume == other.nume) && (denume == other.denume);
}

bool Rational::operator!=(const Rational& other) const {
    return !(*this == other);
}

bool Rational::operator<=(const Rational& other) const {
    int crossProduct1 = nume * other.denume;
    int crossProduct2 = other.nume * denume;
    return crossProduct1 <= crossProduct2;
}

bool Rational::operator>=(const Rational& other) const {
    int crossProduct1 = nume * other.denume;
    int crossProduct2 = other.nume * denume;
    return crossProduct1 >= crossProduct2;
}

Rational& Rational::operator++() {
    nume++;
    denume++;
    simplify(nume, denume);
    return *this;
}

Rational Rational::operator++(int) {
    Rational temp(*this);
    nume++;
    denume++;
    simplify(nume, denume);
    return temp;
}

Rational& Rational::operator--() {
    nume--;
    denume--;
    simplify(nume, denume);
    return *this;
}

Rational Rational::operator--(int) {
    Rational temp(*this);
    nume--;
    denume--;
    simplify(nume, denume);
    return temp;
}

Rational& Rational::operator=(const Rational& other) {
    if (this != &other) {
        nume = other.nume;
        denume = other.denume;
    }
    return *this;
}

Rational& Rational::operator+=(const Rational& other) {
    *this = *this + other;
    return *this;
}

Rational& Rational::operator-=(const Rational& other) {
    *this = *this - other;
    return *this;
}

Rational& Rational::operator*=(const Rational& other) {
    *this = *this * other;
    return *this;
}

Rational& Rational::operator/=(const Rational& other) {
    *this = *this / other;
    return *this;
}

istream& operator>>(istream& in, Rational& rational) {
    cout << "Enter numerator: ";
    in >> rational.nume;

    cout << "Enter denominator (must be positive): ";
    in >> rational.denume;

    if (rational.denume <= 0) {
        cout << "Invalid denominator. Setting denominator to 1." << endl;
        rational.denume = 1;
    }

    Rational::simplify(rational.nume, rational.denume);

    return in;
}

ostream& operator<<(ostream& out, const Rational& rational) {
    out << rational.nume << "/" << rational.denume;
    return out;
}
