#include <iostream>
#include <string>
using namespace std;
class Date {
private:
    int day;
    int month;
    int year;

    bool isLeapYear(int year) const {
        return ((year % 4 == 0 && year % 100 != 0) || (year % 400 == 0));
    }

    int getDaysInMonth(int month, int year) const {
        if (month == 2) {
            return isLeapYear(year) ? 29 : 28;
        } else if (month == 4 || month == 6 || month == 9 || month == 11) {
            return 30;
        } else {
            return 31;
        }
    }

public:
    
    Date(int d, int m, int y) : day(d), month(m), year(y) {}

    bool isValidDate() const {
        if (year < 1 || month < 1 || month > 12 || day < 1 || day > getDaysInMonth(month, year)) {
            return false;
        }
        return true;
    }

    string getDayOfWeek() const {
        if (!isValidDate()) {
            return "Invalid date";
        }

        static const string daysOfWeek[] = {"Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"};

        int a = (14 - month) / 12;
        int y = year - a;
        int m = month + 12 * a - 2;

        int dayOfWeek = (day + y + y / 4 - y / 100 + y / 400 + (31 * m) / 12) % 7;

        return daysOfWeek[dayOfWeek];
    }

    
    int compare(const Date& otherDate) const {
        if (year < otherDate.year || (year == otherDate.year && (month < otherDate.month || (month == otherDate.month && day < otherDate.day)))) {
            return -1; // This date is earlier
        } else if (year == otherDate.year && month == otherDate.month && day == otherDate.day) {
            return 0; // Both dates are equal
        } else {
            return 1; // This date is later
        }
    }
};

int main() {
    // Example usage:
    Date date1(10, 10, 2023);
    Date date2(15, 10, 2023);

    // Validate and display the day of the week for date1
    if (date1.isValidDate()) {
        cout << "Day of the week for date1: " << date1.getDayOfWeek() << endl;
    } else {
        cout << "date1 is not a valid date." << endl;
    }

    // Compare date1 and date2
    int comparisonResult = date1.compare(date2);
    if (comparisonResult < 0) {
        cout << "date1 is earlier than date2." << endl;
    } else if (comparisonResult == 0) {
        cout << "date1 and date2 are equal." << endl;
    } else {
        cout << "date1 is later than date2." << endl;
    }

    return 0;
}

