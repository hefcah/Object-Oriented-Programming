#include <iostream>
#include <string>
using namespace std;
class Contact {
private:
    string name;
    string phoneNumber;
    string email;

public:
    
    Contact(const string& contactName, const string& contactPhoneNumber, const string& contactEmail)
        : name(contactName), phoneNumber(contactPhoneNumber), email(contactEmail) {}

    // Getter methods
    string getName() const { return name; }
    string getPhoneNumber() const { return phoneNumber; }
    string getEmail() const { return email; }

    // Method to display contact details
    void displayContact() const {
        cout << "Name: " << name << endl;
        cout << "Phone Number: " << phoneNumber << endl;
        cout << "Email: " << email << endl;
        cout << endl;
    }
};

class ContactList {
private:
    static const int MAX_CONTACTS = 100;
    Contact contacts[MAX_CONTACTS];
    int contactCount;

public:
    ContactList() : contactCount(0) {}

    void addContact(const Contact& newContact) {
        if (contactCount < MAX_CONTACTS) {
            contacts[contactCount++] = newContact;
            std::cout << "Contact added successfully." << endl;
        } else {
            cout << "Contact list is full. Cannot add more contacts." << endl;
        }
    }

    // Method to search for a contact by name
    void searchContact(const string& contactName) const {
        bool found = false;
        for (int i = 0; i < contactCount; ++i) {
            if (contacts[i].getName() == contactName) {
                contacts[i].displayContact();
                found = true;
            }
        }

        if (!found) {
            std::cout << "Contact not found." << endl;
        }
    }

    // Method to delete a contact by name
    void deleteContact(const string& contactName) {
        int foundIndex = -1;
        for (int i = 0; i < contactCount; ++i) {
            if (contacts[i].getName() == contactName) {
                foundIndex = i;
                break;
            }
        }

        if (foundIndex != -1) {
            // Shift elements to remove the contact
            for (int i = foundIndex; i < contactCount - 1; ++i) {
                contacts[i] = contacts[i + 1];
            }

            --contactCount;
            cout << "Contact deleted successfully." << endl;
        } else {
            cout << "Contact not found." << endl;
        }
    }

    // Method to display all contacts
    void displayContacts() const {
        if (contactCount > 0) {
            cout << "Contact List:" << endl;
            for (int i = 0; i < contactCount; ++i) {
                contacts[i].displayContact();
            }
        } else {
            cout << "Contact list is empty." << endl;
        }
    }
};

int main() {
    ContactList myContactList;
    Contact contact1("Hafsa", "123-456-7890", "hafsa@email.com");
    Contact contact2("Eeman", "987-654-3210", "mani@email.com");

    myContactList.addContact(contact1);
    myContactList.addContact(contact2);

    // Displaying contacts
    myContactList.displayContacts();

    // Searching for a contact
    myContactList.searchContact("Hafsa");

    // Deleting a contact
    myContactList.deleteContact("Eeman");

    // Displaying updated contacts
    myContactList.displayContacts();

    return 0;
}

