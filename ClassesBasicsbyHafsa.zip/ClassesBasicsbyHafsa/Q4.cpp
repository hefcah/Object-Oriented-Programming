#include <iostream>
#include <string>
using namespace std;
class BankAccount {
private:
    string accountNumber;
    string accountHolderName;
    double balance;

public:
    // Constructor to initialize attributes
    BankAccount(const string& accNumber, const string& accHolderName, double initialBalance)
        : accountNumber(accNumber), accountHolderName(accHolderName), balance(initialBalance) {}


    void deposit(double amount) {
        if (amount > 0) {
            balance += amount;
            cout << "Deposit successful. New balance: $" << balance << endl;
        } else {
            cout << "Invalid deposit amount." << endl;
        }
    }

    void withdraw(double amount) {
        if (amount > 0 && amount <= balance) {
            balance -= amount;
            cout << "Withdrawal successful. New balance: Rs" << balance << endl;
        } else {
            cout << "Invalid withdrawal amount or insufficient funds." << endl;
        }
    }

    // Method to display account details
    void displayAccountDetails() const {
        cout << "Account Number: " << accountNumber << endl;
       	cout << "Account Holder: " << accountHolderName << endl;
        cout << "Balance: Rs" << balance << endl;
        cout << endl;
    }
};

int main() {
    // Example usage:
    BankAccount myAccount("123456789", "Hafsa", 1000.0);

    // Display initial account details
    myAccount.displayAccountDetails();

    // Deposit money
    myAccount.deposit(500.0);

    // Withdraw money
    myAccount.withdraw(200.0);

    // Display updated account details
    myAccount.displayAccountDetails();

    return 0;
}

