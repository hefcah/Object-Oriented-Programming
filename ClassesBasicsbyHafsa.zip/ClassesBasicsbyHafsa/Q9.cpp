#include <iostream>
#include <string>
using namespace std;
class Book {
private:
    string title;
    string author;
    int publicationYear;
    bool available;

public:
    // Constructor to initialize attributes
    Book(const string& bookTitle, const string& bookAuthor, int pubYear)
        : title(bookTitle), author(bookAuthor), publicationYear(pubYear), available(true) {}

    // Display book details
    void displayBook() const {
        cout << "Title: " << title << " | Author: " << author
                  << " | Year: " << publicationYear
                  << " | Status: " << (available ? "Available" : "Borrowed") << endl;
    }

    // Borrow the book
    void borrowBook() {
        if (available) {
            available = false;
            cout << "Book borrowed." << endl;
        } else {
            cout << "Book is not available for borrowing." << endl;
        }
    }

    void returnBook() {
        if (!available) {
            available = true;
            cout << "Book returned." << endl;
        } else {
            cout << "Book is already available." << endl;
        }
    }
};

int main() {
    
    Book book1("The Catcher in the Rye", "J.D. Salinger", 1951);
    Book book2("To Kill a Mockingbird", "Harper Lee", 1960);

   
    book1.displayBook();
    book2.displayBook();
    
    book1.borrowBook();

    book1.displayBook();

    book1.returnBook();

   
    book1.displayBook();

    return 0;
}

