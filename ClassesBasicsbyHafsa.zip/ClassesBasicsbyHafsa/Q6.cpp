#include <iostream>
using namespace std;
class Rectangle {
private:
    double length;
    double width;

public:

    Rectangle(double l, double w) : length(l), width(w) {}


    double calculateArea() const {
        return length * width;
    }

    double calculatePerimeter() const {
        return 2 * (length + width);
    }

    // Method to check if two rectangles intersect
    bool intersect(const Rectangle& otherRectangle) const {
        // Check if one rectangle is to the left of the other
        if (length + otherRectangle.length <= max(length, otherRectangle.length) &&
            width + otherRectangle.width <= max(width, otherRectangle.width)) {
            return false;
        }

        // Check if one rectangle is above the other
        if (width + otherRectangle.width <= max(width, otherRectangle.width) &&
            length + otherRectangle.length <= max(length, otherRectangle.length)) {
            return false;
        }

        return true; // Rectangles intersect
    }
};

int main() {
    // Example usage:
    Rectangle rect1(4.0, 2.0);
    Rectangle rect2(8.0, 9.0);
    Rectangle rect3(2.0, 4.0);

    // Calculate and display the area and perimeter of rect1
    cout << "Area of rect1: " << rect1.calculateArea() << endl;
    cout << "Perimeter of rect1: " << rect1.calculatePerimeter() << endl;

    // Check if rect1 intersects with rect2
    if (rect1.intersect(rect2)) {
        cout << "rect1 intersects with rect2." << endl;
    } else {
        cout << "rect1 does not intersect with rect2." << endl;
    }

    // Check if rect1 intersects with rect3
    if (rect1.intersect(rect3)) {
        cout << "rect1 intersects with rect3." << endl;
    } else {
        cout << "rect1 does not intersect with rect3." << endl;
    }

    return 0;
}

