#include <iostream>
#include <string>
using namespace std;
class Car {
private:
    string make;
    string model;
    int year;
    double price;

public:
    // Constructor to initialize attributes
    Car(const string& carMake, const string& carModel, int carYear, double carPrice)
        : make(carMake), model(carModel), year(carYear), price(carPrice) {}

    // Getter methods
    string getMake() const { return make; }
    string getModel() const { return model; }

    
    void displayCar() const {
        cout << "Make: " << make << " | Model: " << model << " | Year: " << year << " | Price: $" << price << endl;
    }
};

class CarInventory {
private:
    static const int MAX_CARS = 100;
    Car cars[MAX_CARS];
    int carCount;

public:
    CarInventory() : carCount(0) {}

    // Add a car to the inventory
    void addCar(const Car& newCar) {
        if (carCount < MAX_CARS) {
            cars[carCount++] = newCar;
            cout << "Car added to the inventory." << endl;
        } else {
            cout << "Car inventory is full. Cannot add more cars." << endl;
        }
    }

    void displayCars() const {
        if (carCount == 0) {
            cout << "Car inventory is empty." << endl;
            return;
        }

        cout << "Car Inventory:" << endl;
        for (int i = 0; i < carCount; ++i) {
            cars[i].displayCar();
        }
    }

    void searchCar(const string& carMake, const string& carModel) const {
        bool found = false;
        for (int i = 0; i < carCount; ++i) {
            if (cars[i].getMake() == carMake && cars[i].getModel() == carModel) {
                cars[i].displayCar();
                found = true;
                break; // Once found, no need to continue searching
            }
        }

        if (!found) {
            cout << "Car not found." << endl;
        }
    }
};

int main() {
    
    CarInventory myCarInventory;

    myCarInventory.addCar(Car("Toyota", "Camry", 2021, 25000.0));
    myCarInventory.addCar(Car("Honda", "Civic", 2022, 22000.0));

    myCarInventory.displayCars();

    myCarInventory.searchCar("Toyota", "Camry");

    return 0;
}

