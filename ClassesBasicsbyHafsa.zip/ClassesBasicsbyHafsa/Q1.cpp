#include <iostream>
#include <string>
using namespace std;
class StudentRecord {
private:
    string name;
    string rollNumber;
    int marks;

public:
    // Constructor to initialize attributes
    StudentRecord(const std::string& studentName, const std::string& studentRollNumber, int studentMarks)
        : name(studentName), rollNumber(studentRollNumber), marks(studentMarks) {}

    void displayRecord() {
        cout << "Name: " << name << endl;
        cout << "Roll Number: " << rollNumber << endl;
       	cout << "Marks: " << marks << endl;
        cout << endl;
    }
};

int main() {

    StudentRecord student1("Hafsa", "1966", 90);
    StudentRecord student2("Eeman", "1111", 100);

    // Displaying student records
    student1.displayRecord();
    student2.displayRecord();

    return 0;
}

