#include <iostream>
#include <string>
using namespace std;
const int MAX_BOOKS = 100;

class Book {
private:
    string ISBN;
    string title;
    string author;
    double price;

public:
    Book(const string& isbn, const string& t, const string& a, double p)
        : ISBN(isbn), title(t), author(a), price(p) {}

    void displayBook() const {
        cout << "ISBN: " << ISBN << " | Title: " << title << " | Author: " << author << " | Price: $" << price << endl;
    }

    string getISBN() const {
        return ISBN;
    }
};

class BookInventory {
private:
    Book books[MAX_BOOKS];
    int bookCount;

public:
    BookInventory() : bookCount(0) {}

    void addBook(const Book& b) {
        if (bookCount < MAX_BOOKS) {
            books[bookCount++] = b;
            cout << "Book added to the inventory." << endl;
        } else {
            cout << "Inventory is full. Cannot add more books." << endl;
        }
    }

    void updateBook(const std::string& isbn, const Book& updatedBook) {
        for (int i = 0; i < bookCount; ++i) {
            if (books[i].getISBN() == isbn) {
                books[i] = updatedBook;
                cout << "Book details updated successfully." << endl;
                return;
            }
        }
        cout << "Book with ISBN " << isbn << " not found." << endl;
    }

    void listBooks() const {
        if (bookCount == 0) {
            cout << "No books in the inventory." << endl;
            return;
        }
        cout << "Book Inventory:" << endl;
        for (int i = 0; i < bookCount; ++i) {
            books[i].displayBook();
        }
    }
};

int main() {
    BookInventory inventory;

    inventory.addBook(Book("978-0-316-76948-0", "The Catcher in the Rye", "J.D. Salinger", 12.99));
    inventory.addBook(Book("978-0-06-112008-4", "To Kill a Mockingbird", "Harper Lee", 9.99));

    inventory.listBooks();

    inventory.updateBook("978-0-06-112008-4", Book("978-0-06-112008-4", "To Kill a Mockingbird", "Harper Lee", 14.99));

    inventory.listBooks();

    return 0;
}

