#include <iostream>
#include <string>
using namespace std;
class EmployeeDetails {
private:
    struct Employee {
        string name;
        int employeeID;
        double salary;
    };

    Employee* employees;  // Dynamic array of employees
    int numberOfEmployees;

public:
    // Constructor to initialize attributes
    EmployeeDetails(int initialCapacity = 10) {
        employees = new Employee[initialCapacity];
        numberOfEmployees = 0;
    }

    // Destructor to free memory
    ~EmployeeDetails() {
        delete[] employees;
    }

    // Method to add an employee
    void addEmployee(const string& name, int employeeID, double salary) {
        if (numberOfEmployees < 10) {
            employees[numberOfEmployees].name = name;
            employees[numberOfEmployees].employeeID = employeeID;
            employees[numberOfEmployees].salary = salary;
            numberOfEmployees++;
            cout << "Employee added successfully." << endl;
        } else {
            cout << "Employee array is full. Cannot add more employees." << endl;
        }
    }

    // Method to delete an employee by ID
    void deleteEmployee(int employeeID) {
        for (int i = 0; i < numberOfEmployees; ++i) {
            if (employees[i].employeeID == employeeID) {
                
                employees[i] = employees[numberOfEmployees - 1];
                numberOfEmployees--;
                cout << "Employee deleted successfully." << endl;
                return;
            }
        }
        cout << "Employee with ID " << employeeID << " not found." << endl;
    }

    // Method to display all employee records
    void displayEmployees() {
        if (numberOfEmployees > 0) {
            cout << "Employee Records:" << std::endl;
            for (int i = 0; i < numberOfEmployees; ++i) {
                cout << "Name: " << employees[i].name << ", ID: " << employees[i].employeeID
                          << ", Salary: " << employees[i].salary << endl;
            }
        } else {
            cout << "No employee records to display." << endl;
        }
    }
};

int main() {
    // Example usage:
    EmployeeDetails employeeDatabase;

    // Adding employees
    employeeDatabase.addEmployee("Hafsa", 101, 90000.0);
    employeeDatabase.addEmployee("Eeman", 102, 100000.0);
    employeeDatabase.addEmployee("Sana", 103, 55000.0);

    // Displaying employee records
    employeeDatabase.displayEmployees();

    // Deleting an employee
    employeeDatabase.deleteEmployee(102);

    // Displaying updated employee records
    employeeDatabase.displayEmployees();

    return 0;
}

