#include <iostream>
#include <string>
using namespace std;
class Movie {
private:
    string title;
    string director;
    int releaseYear;
    double rating;

public:
    
    Movie(const string& movieTitle, const string& movieDirector, int releaseYr, double movieRating)
        : title(movieTitle), director(movieDirector), releaseYear(releaseYr), rating(movieRating) {}

    // Getter method for movie title
    string getTitle() const {
        return title;
    }

    // Display movie details
    void displayMovie() const {
        cout << "Title: " << title << " | Director: " << director
                  << " | Release Year: " << releaseYear
                  << " | Rating: " << rating << endl;
    }
};

class MovieDatabase {
private:
    static const int MAX_MOVIES = 100;
    Movie movies[MAX_MOVIES];
    int movieCount;

public:
    MovieDatabase() : movieCount(0) {}


    void addMovie(const Movie& newMovie) {
        if (movieCount < MAX_MOVIES) {
            movies[movieCount++] = newMovie;
            cout << "Movie added to the database." << endl;
        } else {
            cout << "Movie database is full. Cannot add more movies." << endl;
        }
    }

    void displayDatabase() const {
        if (movieCount == 0) {
            cout << "Movie database is empty." << endl;
            return;
        }

        cout << "Movie Database:" << endl;
        for (int i = 0; i < movieCount; ++i) {
            movies[i].displayMovie();
        }
    }

    // Search for a movie by title
    void searchMovie(const std::string& movieTitle) const {
        bool found = false;
        for (int i = 0; i < movieCount; ++i) {
            if (movies[i].getTitle() == movieTitle) {
                movies[i].displayMovie();
                found = true;
            }
        }

        if (!found) {
            cout << "Movie not found in the database." << endl;
        }
    }
};

int main() {
    
    MovieDatabase myMovieDatabase;

    
    myMovieDatabase.addMovie(Movie("The Shawshank Redemption", "Frank Darabont", 1994, 9.3));
    myMovieDatabase.addMovie(Movie("The Godfather", "Francis Ford Coppola", 1972, 9.2));

    
    myMovieDatabase.displayDatabase();

    
    myMovieDatabase.searchMovie("The Godfather");

    return 0;
}

