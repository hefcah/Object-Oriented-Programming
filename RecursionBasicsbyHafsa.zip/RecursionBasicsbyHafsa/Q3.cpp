#include <iostream>
using namespace std;
void printEvenNumbers(int n)
{
    if (n < 2) 
	{
        return;
    }
    if (n % 2 == 0) 
	{
        cout << n << " ";
        printEvenNumbers(n - 2);
    } 
	else
	{
        printEvenNumbers(n - 1);
    }
}
int main()
{
    int n;
    cout << "Enter a positive integer (n): ";
    cin >> n;
    if (n <= 0)
	{
        cout << "Please enter a positive integer" << endl;
    } 
	else
	{
        cout << "Even numbers from 2 to " << n << ": ";
        printEvenNumbers(n);
        cout << endl;
    }

    return 0;
}

