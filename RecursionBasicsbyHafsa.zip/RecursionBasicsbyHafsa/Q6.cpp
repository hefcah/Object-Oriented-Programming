#include<iostream>
using namespace std;
int fib(int n)
{
	if (n<2)
	{
		return n;
	}
	return fib (n-2)+fib (n-1);
}

int main()
{
	int n;
	cout<<"enter number"<<endl;
	cin>>n;
	cout<<"term at fib at position n is "<<fib(n)<<endl;
	
}
