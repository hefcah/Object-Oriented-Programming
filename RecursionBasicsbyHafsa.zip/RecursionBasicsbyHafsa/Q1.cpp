#include <iostream>
using namespace std;
int calculateSum(int n)
 {
    if (n == 1)
	 {
        return 1;
    } 
	else
	{
        return n + calculateSum(n - 1);
    }
}
int main() 
{
    int n;
    cout << "Enter a positive integer (n) ";
    cin >> n;
    if (n <= 0) 
	{
        cout << "Please enter a positive integer." << std::endl;
    } else
	{
        int sum = calculateSum(n);
        cout << "The sum of numbers from 1 to " << n << " is " << sum << endl;
    }

    return 0;
}

