#include <iostream>
using namespace std;
void printNumbers(int n) 
{
    if (n == 1) 
	{
        cout << n << endl;
    } 
	else 
	{
        cout << n << " ";
        printNumbers(n - 1);
    }
}
int main()
 {
    int n;
    cout << "Enter a positive integer (n) ";
    cin >> n;
    if (n <= 0) 
	{
        cout << "Please enter a positive integer" << endl;
    } 
	else
	{
        cout << "Numbers from " << n << " down to 1: ";
        printNumbers(n);
    }
    return 0;
}

