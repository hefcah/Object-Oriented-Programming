#include <iostream>
using namespace std;
void decimalToBinary(int n)
{
    if (n <= 1) 
	{
        cout << n;
    }
	else 
	{
        decimalToBinary(n / 2);
        cout << n % 2;
    }
}

int main() 
{
    int decimalNumber;
    cout << "Enter a decimal number: ";
    cin >> decimalNumber;

    if (decimalNumber < 0)
	{
    	cout << "Please enter a non-negative decimal number." << std::endl;
    } 
	else 
	{
        cout << "Binary representation: ";
        if (decimalNumber == 0)
		{
            cout << "0"; // Special case: 0 in binary is just 0.
        } 
		else 
		{
            decimalToBinary(decimalNumber);
        }
        cout << endl;
    }

    return 0;
}

