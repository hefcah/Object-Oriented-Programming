#include <iostream>
using namespace std;
void printTriangle(int n, int currentRow = 0, int currentCol = 0)
{
    if (currentRow == n)
	{
        return;
    } 
	else 
	{
        if (currentCol <= currentRow)
		{
            cout << "*";
        }
        if (currentCol == currentRow)
		{
            cout << endl;
            printTriangle(n, currentRow + 1, 0);
        } 
		else 
		{
            printTriangle(n, currentRow, currentCol + 1);
        }
    }
}

int main() 
{
    int n;
    cout << "Enter the number of rows for the right-angled triangle: ";
	cin >> n;

    if (n <= 0)
	{
        cout << "Please enter a positive integer." << endl;
    }
	 else
	{
        cout << "Right-angled triangle pattern:" << endl;
        printTriangle(n);
    }

    return 0;
}

