#include <iostream>
#include <string>
using namespace std;
const int MAX_STUDENTS = 40;
struct Student {
    std::string name;
    int rollNumber;
    double marks;
};

int main() {
    Student students[MAX_STUDENTS];
    int numStudents;
    do {
        cout << "Enter the number of students (1-" << MAX_STUDENTS << "): ";
        cin >> numStudents;
    } while (numStudents <= 0 || numStudents > MAX_STUDENTS);
    for (int i = 0; i < numStudents; i++) {
        cout << "Enter details for student " << i + 1 << ":" << endl;
        cout << "Name: ";
        cin.ignore(); // Ignore the newline character left by previous input
        getline(std::cin, students[i].name);
        cout << "Roll Number: ";
        cin >> students[i].rollNumber;
        cout << "Marks: ";
        cin >> students[i].marks;
    }
    cout << "Student Records:" << endl;
    for (int i = 0; i < numStudents; i++) {
	cout << "Student " << i + 1 << " - Name: " << students[i].name << ", Roll Number: " << students[i].rollNumber << ", Marks: " << students[i].marks << endl;
    }

    return 0;
}

