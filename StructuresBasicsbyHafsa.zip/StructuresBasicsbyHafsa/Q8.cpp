#include <iostream>
#include <string>
using namespace std;
const int MAX_CARS = 20;
struct Car {
    string make;
    string model;
    int year;
    double price;
};

// Function to add a car to the inventory
void addCar(Car inventory[], int& numCars, const string& make, const string& model, int year, double price) {
    if (numCars < MAX_CARS) {
        Car newCar;
        newCar.make = make;
        newCar.model = model;
        newCar.year = year;
        newCar.price = price;
        inventory[numCars] = newCar;
        numCars++;
        cout << "Car added to the inventory." << endl;
    } else {
        cout << "Inventory is full. Cannot add more cars." << endl;
    }
}

void searchCar(const Car inventory[], int numCars, const std::string& make, const string& model) {
    bool found = false;
    for (int i = 0; i < numCars; i++) {
        if (inventory[i].make == make && inventory[i].model == model) {
            found = true;
            cout << "Make: " << inventory[i].make << endl;
            cout << "Model: " << inventory[i].model << endl;
            cout << "Year: " << inventory[i].year << endl;
            cout << "Price: $" << inventory[i].price << endl;
            cout << "-------------------" << endl;
        }
    }
    if (!found) {
        cout << "Car not found in the inventory." << std::endl;
    }
}

// Function to display all cars in the inventory
void displayInventory(const Car inventory[], int numCars) {
    for (int i = 0; i < numCars; i++) {
        cout << "Make: " << inventory[i].make << endl;
        cout << "Model: " << inventory[i].model << endl;
        cout << "Year: " << inventory[i].year << endl;
        cout << "Price: $" << inventory[i].price << endl;
        cout << "-------------------" << std::endl;
    }
}

int main() {
    Car inventory[MAX_CARS]; 
    int numCars = 0; 
    addCar(inventory, numCars, "Toyota", "Camry", 2020, 25000.0);
    addCar(inventory, numCars, "Honda", "Civic", 2021, 22000.0);
    addCar(inventory, numCars, "Ford", "Mustang", 2019, 35000.0);

    cout << "Search Result:" << endl;
    searchCar(inventory, numCars, "Toyota", "Camry");
    cout << "Car Inventory:" << endl;
    displayInventory(inventory, numCars);

    return 0;
}

