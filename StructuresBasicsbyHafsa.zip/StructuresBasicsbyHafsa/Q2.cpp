#include <iostream>
#include <string>
using namespace std;
const int MAX_EMPLOYEES = 55;
struct Employee {
    string name;
    int employeeID;
    double salary;
};

void addEmployee(Employee employees[], int& numEmployees, const std::string& name, int employeeID, double salary) {
    if (numEmployees < MAX_EMPLOYEES) {
        Employee newEmployee;
        newEmployee.name = name;
        newEmployee.employeeID = employeeID;
        newEmployee.salary = salary;
        employees[numEmployees] = newEmployee;
        numEmployees++;
        cout << "Employee record added." << endl;
    } else {
        cout << "Employee database is full. Cannot add more records." << endl;
    }
}
void deleteEmployee(Employee employees[], int& numEmployees, int employeeID) {
    for (int i = 0; i < numEmployees; i++) {
        if (employees[i].employeeID == employeeID) {
            employees[i] = employees[numEmployees - 1];
            numEmployees--;
            cout << "Employee record deleted." << endl;
            return; 
        }
    }
    cout << "Employee with ID " << employeeID << " not found in the database. No record deleted." << endl;
}
void displayEmployees(const Employee employees[], int numEmployees) {
    for (int i = 0; i < numEmployees; i++) {
        cout << "Name: " << employees[i].name << endl;
        cout << "Employee ID: " << employees[i].employeeID << endl;
        cout << "Salary: $" << employees[i].salary << endl;
        cout << "-------------------" << endl;
    }
}

int main() {
    Employee employeeDatabase[MAX_EMPLOYEES]; 
    int numEmployees = 0; 
    addEmployee(employeeDatabase, numEmployees, "John Doe", 101, 55000.0);
    addEmployee(employeeDatabase, numEmployees, "Jane Smith", 102, 60000.0);
    addEmployee(employeeDatabase, numEmployees, "Alice Johnson", 103, 62000.0);
	cout << "Employee Database:" << endl;
    displayEmployees(employeeDatabase, numEmployees);

    deleteEmployee(employeeDatabase, numEmployees, 102);

    cout << "Updated Employee Database:" << endl;
    displayEmployees(employeeDatabase, numEmployees);

    return 0;
}

