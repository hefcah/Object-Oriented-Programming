#include <iostream>
using namespace std;
struct Date {
    int day;
    int month;
    int year;
};

bool isValidDate(const Date& date) {
    if (date.year < 1 || date.month < 1 || date.month > 12 || date.day < 1)
        return false;

    int daysInMonth = 31;
    if (date.month == 4 || date.month == 6 || date.month == 9 || date.month == 11)
        daysInMonth = 30;
    else if (date.month == 2) {
        if ((date.year % 4 == 0 && date.year % 100 != 0) || (date.year % 400 == 0))
            daysInMonth = 29;
        else
            daysInMonth = 28;
    }

    return date.day <= daysInMonth;
}

// Function to find the day of the week for a given date (Zeller's Congruence)
std::string getDayOfWeek(const Date& date) {
    int q = date.day;
    int m = date.month;
    int y = date.year;
    if (m < 3) {
        m += 12;
        y--;
    }
    int K = y % 100;
    int J = y / 100;
    int h = (q + 13 * (m + 1) / 5 + K + K / 4 + J / 4 - 2 * J) % 7;

    string daysOfWeek[] = {"Saturday", "Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday"};
    return daysOfWeek[(h + 5) % 7]; 
}
int compareDates(const Date& date1, const Date& date2) {
    if (date1.year != date2.year)
        return date1.year - date2.year;
    if (date1.month != date2.month)
        return date1.month - date2.month;
    return date1.day - date2.day;
}

int main() {
    Date date1, date2;
    cout << "Enter date 1 (day month year): ";
    cin >> date1.day >> date1.month >> date1.year;

    // Input date 2
    std::cout << "Enter date 2 (day month year): ";
    std::cin >> date2.day >> date2.month >> date2.year;

    if (isValidDate(date1) && isValidDate(date2))
	{
        cout << "Date 1 is a valid date." << endl;
        cout << "Date 2 is a valid date." << endl;
    } else {
        cout << "One or both of the input dates are not valid." << endl;
        return 1;
    }

    cout << "Day of the week for Date 1: " << getDayOfWeek(date1) << endl;
    cout << "Day of the week for Date 2: " << getDayOfWeek(date2) << endl;

    int result = compareDates(date1, date2);
    if (result < 0)
        cout << "Date 1 is earlier than Date 2." << endl;
    else if (result > 0)
        cout << "Date 1 is later than Date 2." << endl;
    else
        cout << "Date 1 and Date 2 are the same." << endl;

    return 0;
}

