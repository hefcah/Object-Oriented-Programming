#include <iostream>
#include <string>
using namespace std;
struct BankAccount {
    string accountNumber;
    string accountHolderName;
    double balance;
};
void deposit(BankAccount& account, double amount) {
    if (amount > 0) {
        account.balance += amount;
        cout << "Deposit of $" << amount << " successful." << endl;
    } else {
        cout << "Invalid deposit amount." << endl;
    }
}

// Function to withdraw money from the account
void withdraw(BankAccount& account, double amount) {
    if (amount > 0 && amount <= account.balance) {
        account.balance -= amount;
        cout << "Withdrawal of $" << amount << " successful." << endl;
    } else {
        cout << "Invalid withdrawal amount or insufficient balance." << endl;
    }
}

void displayAccountDetails(const BankAccount& account) {
    cout << "Account Number: " << account.accountNumber << endl;
    cout << "Account Holder's Name: " << account.accountHolderName << endl;
    cout << "Balance: $" << account.balance << std::endl;
}

int main() {
    BankAccount account;
    account.accountNumber = "123456789";
    account.accountHolderName = "John Doe";
    account.balance = 1000.0;
    cout << "Account Details:" << endl;
    displayAccountDetails(account);
    deposit(account, 500.0);
    withdraw(account, 300.0);
    cout << "Updated Account Details:" << endl;
    displayAccountDetails(account);

    return 0;
}

