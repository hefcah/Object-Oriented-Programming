#include <iostream>
using namespace std;
struct Rectangle {
    double length;
    double width;
};

double calculateArea(const Rectangle& rect) {
    return rect.length * rect.width;
}
double calculatePerimeter(const Rectangle& rect) {
    return 2 * (rect.length + rect.width);
}
bool doRectanglesIntersect(const Rectangle& rect1, const Rectangle& rect2) {

    double rect1_x1 = 0.0;
    double rect1_x2 = rect1.length;
    double rect1_y1 = 0.0;
    double rect1_y2 = rect1.width;

    double rect2_x1 = 0.0;
    double rect2_x2 = rect2.length;
    double rect2_y1 = 0.0;
    double rect2_y2 = rect2.width;

    if (rect1_x1 < rect2_x2 && rect1_x2 > rect2_x1 && rect1_y1 < rect2_y2 && rect1_y2 > rect2_y1) {
        return true;
    }

    return false;
}

int main() {
    Rectangle rect1, rect2;

    cout << "Enter length and width of the first rectangle: ";
    cin >> rect1.length >> rect1.width;
    cout << "Enter length and width of the second rectangle: ";
    cin >> rect2.length >> rect2.width;

    cout << "Rectangle 1 Area: " << calculateArea(rect1) << endl;
    cout << "Rectangle 1 Perimeter: " << calculatePerimeter(rect1) << endl;

    cout << "Rectangle 2 Area: " << calculateArea(rect2) << endl;
    cout << "Rectangle 2 Perimeter: " << calculatePerimeter(rect2) << endl;
    if (doRectanglesIntersect(rect1, rect2)) {
        cout << "The rectangles intersect." << endl;
    } else {
        cout << "The rectangles do not intersect." << endl;
    }

    return 0;
}

