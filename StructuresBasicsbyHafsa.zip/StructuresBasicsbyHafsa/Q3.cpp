#include <iostream>
#include <string>
using namespace std;
const int MAX_BOOKS = 25;
struct Book {
    string title;
    string author;
    string ISBN;
    double price;
};
void addBook(Book inventory[], int& numBooks, const std::string& title, const std::string& author, const std::string& ISBN, double price) {
    if (numBooks < MAX_BOOKS) {
        Book newBook;
        newBook.title = title;
        newBook.author = author;
        newBook.ISBN = ISBN;
        newBook.price = price;
        inventory[numBooks] = newBook;
        numBooks++;
        cout << "Book added to the inventory." << endl;
    } else {
        cout << "Inventory is full. Cannot add more books." << endl;
    }
}

void updateBook(Book inventory[], int numBooks, const std::string& ISBN, double newPrice) {
    bool found = false;
    for (int i = 0; i < numBooks; i++) {
        if (inventory[i].ISBN == ISBN) {
            found = true;
            inventory[i].price = newPrice;
            cout << "Book information updated." << endl;
        }
    }
    if (!found) {
        std::cout << "Book with ISBN " << ISBN << " not found in the inventory." << endl;
    }
}

void displayInventory(const Book inventory[], int numBooks) {
    for (int i = 0; i < numBooks; i++) {
        cout << "Title: " << inventory[i].title << endl;
        cout << "Author: " << inventory[i].author << endl;
        cout << "ISBN: " << inventory[i].ISBN << endl;
        cout << "Price: $" << inventory[i].price << endl;
        cout << "-------------------" << endl;
    }
}

int main() {
    Book bookInventory[MAX_BOOKS]; 
    int numBooks = 0; 
    addBook(bookInventory, numBooks, "The Catcher in the Rye", "J.D. Salinger", "978-0-316-76948-0", 9.99);
    addBook(bookInventory, numBooks, "To Kill a Mockingbird", "Harper Lee", "978-0-06-112008-4", 12.99);
    addBook(bookInventory, numBooks, "1984", "George Orwell", "978-0-452-28423-4", 14.99);
    updateBook(bookInventory, numBooks, "978-0-316-76948-0", 10.99);
    cout << "Book Inventory:" << endl;
    displayInventory(bookInventory, numBooks);

    return 0;
}

