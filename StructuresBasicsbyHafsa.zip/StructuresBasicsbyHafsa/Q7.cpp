#include <iostream>
#include <string>
using namespace std;
const int MAX_CONTACTS = 30;

struct Contact {
    string name;
    string phoneNumber;
    string email;
};

void addContact(Contact contacts[], int& numContacts, const std::string& name, const std::string& phoneNumber, const std::string& email) {
    if (numContacts < MAX_CONTACTS) {
        contacts[numContacts++] = {name, phoneNumber, email};
        std::cout << "Contact added to the list." << endl;
    } else {
        cout << "Contact list is full. Cannot add more contacts." << endl;
    }
}

void searchContact(const Contact contacts[], int numContacts, const std::string& name) {
    bool found = false;
    for (int i = 0; i < numContacts; i++) {
        if (contacts[i].name == name) {
            found = true;
            cout << "Name: " << contacts[i].name << "\nPhone Number: " << contacts[i].phoneNumber << "\nEmail: " << contacts[i].email << "\n-------------------" << endl;
        }
    }
    if (!found) {
        cout << "Contact not found in the list." << endl;
    }
}

void deleteContact(Contact contacts[], int& numContacts, const std::string& name) {
    for (int i = 0; i < numContacts; i++) {
        if (contacts[i].name == name) {
            contacts[i] = contacts[--numContacts];
            cout << "Contact deleted from the list." << endl;
            return;
        }
    }
    cout << "Contact not found in the list. No contact deleted." << endl;
}

void displayContacts(const Contact contacts[], int numContacts) {
    for (int i = 0; i < numContacts; i++) {
        cout << "Name: " << contacts[i].name << "\nPhone Number: " << contacts[i].phoneNumber << "\nEmail: " << contacts[i].email << "\n-------------------" << endl;
    }
}

int main() {
    Contact contactList[MAX_CONTACTS];
    int numContacts = 0;
    addContact(contactList, numContacts, "John Doe", "123-456-7890", "john@example.com");
    addContact(contactList, numContacts, "Jane Smith", "987-654-3210", "jane@example.com");
    addContact(contactList, numContacts, "Alice Johnson", "555-555-5555", "alice@example.com");

    cout << "Search Result:" << endl;
    searchContact(contactList, numContacts, "John Doe");

    deleteContact(contactList, numContacts, "Jane Smith");

    cout << "Contact List:" << endl;
    displayContacts(contactList, numContacts);

    return 0;
}

