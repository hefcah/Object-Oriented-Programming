#include <iostream>
using namespace std;
int main() 
{
    int size;
    cout << "Enter the size of the integer array: ";
    cin >> size;
    int* dynamicArray = new int[size];

    cout << "Enter " << size << " integer values:" << std::endl;
    for (int i = 0; i < size; i++)
	{
        cin >> dynamicArray[i];
    }

    // Display the values stored in the dynamically allocated array
    cout << "You entered the following values:" << std::endl;
    for (int i = 0; i < size; i++) 
	{
        cout << dynamicArray[i] << " ";
    }
    cout << endl;
    delete[] dynamicArray;

    return 0;
}

