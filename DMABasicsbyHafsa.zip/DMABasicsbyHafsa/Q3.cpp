#include <iostream>
using namespace std;
int** allocateMatrix(int rows, int cols)
   {
    int** matrix = new int*[rows];
    for (int i = 0; i < rows; i++)
    {
	
	 matrix[i] = new int[cols];
    return matrix;
   }
}
void deallocateMatrix(int** matrix, int rows) 
{
    for (int i = 0; i < rows; i++) 
	{
	delete[] matrix[i];
    delete[] matrix;
}
}

void inputMatrix(int** matrix, int rows, int cols) 
{
    cout << "Enter matrix elements:" << endl;
    for (int i = 0; i < rows; i++)
    {
        for (int j = 0; j < cols; j++) 
		{
		cin >> matrix[i][j];
		}
	}

int main() 
{
    int rows1, cols1, rows2, cols2;
    cin >> rows1;
	cin >> cols1;
	cin >> rows2;
	cin >> cols2;

   

    int** matrix1 = allocateMatrix(rows1, cols1);
    int** matrix2 = allocateMatrix(rows2, cols2);

    inputMatrix(matrix1, rows1, cols1);
    inputMatrix(matrix2, rows2, cols2);

    int** result = allocateMatrix(rows1, cols2);

    for (int i = 0; i < rows1; i++)
    {
        for (int j = 0; j < cols2; j++)
        {
		
            for (int k = 0; k < cols1; k++)
            {
			
                result[i][j] += matrix1[i][k] * matrix2[k][j];
	}   
	}
}
    cout << "Resulting Matrix:" << endl;
    for (int i = 0; i < rows1; i++) 
	{
        for (int j = 0; j < cols2; j++) 
        {

		cout << result[i][j] << "\t";
        cout << endl;
    	}
}
    deallocateMatrix(matrix1, rows1);
    deallocateMatrix(matrix2, rows2);
    deallocateMatrix(result, rows1);

    return 0;
}

