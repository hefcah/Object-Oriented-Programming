#include <iostream>
using namespace std;
int main() 
{
    
    int* dynamicInt = new int;
    *dynamicInt ;
    cout<<"enter integer"<<endl;
	cin>>*dynamicInt;
    cout << "Dynamically allocated integer: " << *dynamicInt << endl;

    delete dynamicInt;

    return 0;
}
