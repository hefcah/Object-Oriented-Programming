#include <iostream>
#include <string>
using namespace std;
int main() 
{
    int numStrings;
	cout << "Enter the number of strings: ";
    cin >> numStrings;

    cin.ignore();

    string** stringArray = new string*[numStrings];

    for (int i = 0; i < numStrings; ++i) 
	{
        cout << "Enter string " << (i + 1) << ": ";
        string inputString;
        getline(cin, inputString);
        stringArray[i] = new string(inputString);
    }

    cout << "The strings in reverse order:" << endl;
    for (int i = numStrings - 1; i >= 0; --i) 
	{
    cout << *stringArray[i] << endl;
    }

    for (int i = 0; i < numStrings; ++i)
	 {
        delete stringArray[i];
    }
    delete[] stringArray;

    return 0;
}

