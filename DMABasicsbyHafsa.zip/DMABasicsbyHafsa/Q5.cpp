#include <iostream>
#include <string>
using namespace std;
int main()
 {
    int numStrings;

    cout << "Enter the number of strings: ";
    cin >> numStrings;

    cin.ignore();

    string* stringArray = new string[numStrings];

    for (int i = 0; i < numStrings; ++i) 
	{
        cout << "Enter string " << (i + 1) << ": ";
        getline(cin, stringArray[i]);
    }
	cout << "The strings you entered:" << endl;
    for (int i = 0; i < numStrings; ++i)
	 {
    cout << "String " << (i + 1) << ": " << stringArray[i] << std::endl;
    }

    delete[] stringArray;

    return 0;
}

