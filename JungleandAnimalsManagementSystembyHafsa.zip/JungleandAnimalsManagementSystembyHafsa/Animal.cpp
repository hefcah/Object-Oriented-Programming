
// Animal.cpp
#include "Animal.h"
using namespace std;
// Initializing the static member variable
int Animal::totalAnimals = 0;
// Default Constructor

Animal::Animal() : age(0), availability(false) {
    totalAnimals++;
    //This is the default constructor for the Animal class. It initializes age to 0, sets availability to false, and increments the totalAnimals count.
}
// Parameterized Constructor
Animal::Animal(const string& name, const string& species, float age, bool availability)
    : name(name), species(species), age(age), availability(availability) {
    totalAnimals++;
    //This is a parameterized constructor for the Animal class.It takes value and initializes the corresponding member variables.It also increments totalAnimals
}
// Destructor
Animal::~Animal() {
    totalAnimals--;
    cout << "Destroying " << name << ", the " << species << endl;
    // It decrements totalAnimals and prints a message indicating the destruction of an animal
}
// Getter methods
string Animal::getName() const {
    return name;
}
// Setter methods
void Animal::setName(const string& name) {
    this->name = name;
}

string Animal::getSpecies() const {
    return species;
}

void Animal::setSpecies(const string& species) {
    this->species = species;
}

float Animal::getAge() const {
    return age;
}

void Animal::setAge(float age) {
    this->age = age;
}

bool Animal::checkAvailability() const {
    return availability;
}

void Animal::setAvailability(bool availability) {
    this->availability = availability;
}
// Method to input attributes interactively
void Animal::inputAttributes() {
    cout << "Enter Name: ";
    cin >> name;
    cout << "Enter Species: ";
    cin >> species;
    cout << "Enter Age: ";
    cin >> age;
    cout << "Enter Availability (1 for available, 0 for not available): ";
    cin >> availability;
}
// Method to display information about the animal
void Animal::display() const {
    cout << "Animal's name " << name << endl;
    cout << "Animal's species " << species << endl;
    cout << "Animal's age " << age << endl;
    cout << "Animal's availability " << availability << endl;
}

// Static method to get the total number of animals
int Animal::getNumberOfAnimals() {
    return totalAnimals;
}
