// Jungle.h
#include "Animal.h"
using namespace std;
class Jungle {
private:
    static const int maxSize = 80;
    Animal* ptr[maxSize];
    int currentSize;
    //Here, a class Jungle is defined with private data members maxSize (a constant), an array of pointers to Animal objects (ptr), and an integer currentSize. Public member functions and constructors/destructor are declared.
public:
    // Constructor and Destructor
    Jungle();
    ~Jungle();

    // Methods to manipulate animals in the jungle
    void addAnimal(const string& name, const std::string& species, float age, bool availability);
    void removeAnimal(const std::string& nameToRemove);
    const Animal* searchAnimalByName(const string& nameToFind) const;
    const Animal* searchAnimalBySpecies(const string& speciesToFind) const;
    const Animal* searchAnimalByAge(float ageToFind) const;
    void displayJungle() const;
};

