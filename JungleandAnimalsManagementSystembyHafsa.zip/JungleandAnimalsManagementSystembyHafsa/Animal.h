// Animal.h
#include <iostream>
#include <string>
using namespace std;
class Animal {
private:
    string name;
    string species;
    float age;
    bool availability;
    static int totalAnimals;
    //Here, a class Animal is defined with private data members and a static variable totalAnimals. Public member functions and constructors/destructor are declared.
public:
    // Constructors and Destructor
    Animal();
    Animal(const string& name, const string& species, float age, bool availability);
    ~Animal();
    // Getter and Setter methods
    string getName() const;
    void setName(const string& name);

    string getSpecies() const;
    void setSpecies(const string& species);

    float getAge() const;
    void setAge(float age);

    bool checkAvailability() const;
    void setAvailability(bool availability);

    // Input and display methods
    void inputAttributes();
    void display() const;
    // Static method to get the total number of animals
    static int getNumberOfAnimals();
};

