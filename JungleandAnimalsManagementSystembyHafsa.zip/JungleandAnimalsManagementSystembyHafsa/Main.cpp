// main.cpp
#include <iostream>
#include "Jungle.h"
using namespace std;
int main() {
    // Creating an instance of the Jungle class
    Jungle jingle;
    // Variable to store user's choice
    int choice = -1;
    // Main menu loop
    while (choice != 0)
    //This initializes a variable choice to -1 and starts a while loop that continues until choice becomes 0
    {
        // Displaying the main menu
        cout << "----------------------------------------" << endl;
        cout << "  Jungle and Animal Management System" << endl;
        cout << "------------------------------------------" << endl;
        cout << "Welcome to Beastie Jungle" << std::endl;
        cout << "Below are the options for your convenience. Happy Jungling!!!" << endl;
        cout << "1. Add new animals to Jungle" << endl;
        cout << "2. Remove animals from Jungle" << endl;
        cout << "3. Search for animals by name" << endl;
        cout << "4. Search for animals by age" << endl;
        cout << "5. Search for animals by species" << endl;
        cout << "6. Display all available animals in the jungle " << endl;
        cout << "7. Check the total number of available animals in the Jungle" << endl;
        cout << "0. Exit" << std::endl;
        // Getting user's choice
        cout << "Enter Your Choice: ";
        cin >> choice;
        // Handling user's choice
        if (choice == 1) {
            // Adding a new animal to the jungle
            string name, species;
            float age;
            bool availability;
            cout << "Enter Name of Animal: ";
            cin >> name;
            cout << "Enter Species of Animal: ";
            cin >> species;
            cout << "Enter Age of Animal: ";
            cin >> age;
            cout << "Enter Availability of Animal (1 for available, 0 for not available): ";
            cin >> availability;
            jingle.addAnimal(name, species, age, availability);
        }
        else if (choice == 2) {
            // Removing an animal from the jungle
            string name;
            cout << "Enter the name of the animal you want to remove: ";
            cin >> name;
            jingle.removeAnimal(name);
        }
        else if (choice == 3) {
            // Searching for an animal by name
            string name;
            cout << "Enter the name of the animal you want to search for: ";
            cin >> name;
            const Animal* foundAnimal = jingle.searchAnimalByName(name);
            if (foundAnimal) {
                foundAnimal->display();
            }
            else {
                cout << "Animal not found: " << name << endl;
            }
        }
        else if (choice == 4) {
            // Searching for an animal by age
            float age;
            cout << "Enter the age: ";
            cin >> age;
            const Animal* foundAnimal = jingle.searchAnimalByAge(age);
            if (foundAnimal) {
                foundAnimal->display();
            }
            else {
                cout << "Animal not found for age: " << age << endl;
            }
        }
        else if (choice == 5) {
            // Searching for an animal by species
            string species;
            cout << "Enter the species: ";
            cin >> species;
            const Animal* foundAnimal = jingle.searchAnimalBySpecies(species);
            if (foundAnimal) {
                foundAnimal->display();
            }
            else {
                cout << "Animal not found for species: " << species << endl;
            }
        }
        else if (choice == 6) {
            // Displaying all animals in the jungle
            jingle.displayJungle();
        }
        else if (choice == 7) {
            // Checking the total number of available animals in the jungle
            cout << "Total number of available animals in the Jungle: " << Animal::getNumberOfAnimals() << endl;
        }
        else if (choice == 0) {
            // Exiting the interface
            cout << "Exiting Interface" << endl;
            break;
        }
        else {
            // Handling invalid choice
            cout << "Invalid choice" << endl;
        }
    }
    return 0;
}

