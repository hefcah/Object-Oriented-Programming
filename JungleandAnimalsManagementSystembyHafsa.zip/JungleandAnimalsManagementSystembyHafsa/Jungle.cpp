// Jungle.cpp
#include "Jungle.h"
using namespace std;
// Constructor
Jungle::Jungle() : currentSize(0) {
    for (int i = 0; i < maxSize; ++i) {
        ptr[i] = nullptr;
    }
}
// Destructor
Jungle::~Jungle() {
    for (int i = 0; i < currentSize; ++i) {
        delete ptr[i];
        //This is the destructor for the Jungle class. It iterates over the elements of the ptr array and deletes each Animal object
    }
    //This is the default constructor for the Jungle class. It initializes currentSize to 0 and sets all elements of the ptr array to nullptr
}
// Method to add an animal to the jungle
void Jungle::addAnimal(const string& name, const string& species, float age, bool availability) {
    if (currentSize < maxSize) {
        ptr[currentSize] = new Animal(name, species, age, availability);
        cout << "Animal added: " << name << endl;
        currentSize++;
    }
    else {
        cout << "Jungle is full! Cannot add more animals." << endl;
    }
}
// Method to remove an animal from the jungle
void Jungle::removeAnimal(const string& nameToRemove) {
    for (int i = 0; i < currentSize; ++i) {
        if (ptr[i] && ptr[i]->getName() == nameToRemove) {
            // Deleting the Animal object and adjusting the array
            delete ptr[i];
            for (int j = i; j < currentSize - 1; ++j) {
                ptr[j] = ptr[j + 1];
            }
            cout << "Animal removed: " << nameToRemove << endl;
            currentSize--;
            return;
        }
    }
    cout << "Animal not found: " << nameToRemove << endl;
}
// Method to search for an animal by name
const Animal* Jungle::searchAnimalByName(const std::string& nameToFind) const {
    for (int i = 0; i < currentSize; ++i) {
        if (ptr[i] && ptr[i]->getName() == nameToFind) {
            return ptr[i];
        }
    }
    return nullptr;
}

// Method to search for an animal by species
const Animal* Jungle::searchAnimalBySpecies(const string& speciesToFind) const {
    for (int i = 0; i < currentSize; ++i) {
        if (ptr[i] && ptr[i]->getSpecies() == speciesToFind) {
            return ptr[i];
        }
    }
    return nullptr;
}

// Method to search for an animal by age
const Animal* Jungle::searchAnimalByAge(float ageToFind) const {
    for (int i = 0; i < currentSize; ++i) {
        if (ptr[i] && ptr[i]->getAge() == ageToFind) {
            return ptr[i];
        }
    }
    return nullptr;
}

// Method to display all animals in the jungle
void Jungle::displayJungle() const {
    for (int i = 0; i < currentSize; ++i) {
        if (ptr[i]) {
            ptr[i]->display();
            cout << "-----------------------------" << endl;
        }
    }
}

